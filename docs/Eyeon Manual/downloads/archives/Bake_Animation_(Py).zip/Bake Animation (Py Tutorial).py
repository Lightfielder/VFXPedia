## Bake Animation
## by Stefan Ihringer, stefan@bildfehler.de
##
## Python tool script example based on the "Bake Animation" script that ships with Fusion.
##
## Lessons:
## - retrieving list of inputs from a tool
## - retrieving attributes of an input
## - accessing inputs at arbitrary frames
## - creating bezier spline animation
## - locking and undo of composition
## Things left undone:
## - proper error checking and exception handling (we assume it's a valid tool script)
## - maybe defining a custom frame range to be baked?




	

# get all animated inputs
inputlist = tool.GetInputList()

# dictionary to store valid inputs. The input IDs will be used for keys which
# is more useful for user dialog later on than numeric keys.
inputs = {}

for inp in inputlist.itervalues():
	if inp.GetConnectedOutput() is not None or inp.GetExpression() is not None:
		if inp.GetAttrs()["INPS_DataType"] not in ["Image", "Mask", "Particles", "DataType3D"]:
			inputs[inp.ID] = inp

if len(inputs) == 0:
	raise Exception("This tool has no inputs which can be baked by this script.")




# Build user dialog that displays a checkbox for each input that could be baked.
# The array containting the checkboxes needs to be a 1-based dictionary. Each
# entry is another dictionary with numeric as well as string keys. This is
# due to the LUA heritage of eyeonscript.
dialog = {}
i = 1
for inp in inputs.itervalues():
	#                .-- internal ID of checkbox
	#                :              .-- type of control
	#                :              :         .-- user-friendly label
	#                :              :         :
	dialog[i] = {1: inp.ID, 2: "Checkbox", "Name": inp.Name}
	i = i + 1




# show dialog box using the AskUser function. It will return None if the dialog
# was canceled or a dictionary of values for each checkbox.
ret = composition.AskUser("Select inputs to be baked:", dialog)

if ret is not None:
	# ret will look something like this: {"Input1": 1.0, "Input2": 0.0}
	# 1.0 means the checkbox was selected, 0.0 means it was unselected.
	# This loop looks at all return values and filters the inputs dictionary
	# so only selected items remain.
	for k, v in ret.iteritems():
		try:
			if v == 0:
				del inputs[k]
		except:
			# just in case something goes wrong
			pass




	if len(inputs) > 0:
		# Lock the comp and read the frame range to be baked
		composition.Lock()
		timestart = int(composition.GetAttrs()["COMPN_GlobalStart"])
		timeend = int(composition.GetAttrs()["COMPN_GlobalEnd"])
		try:
			# while the comp is locked, everything should be inside a try-finally-block
			# so we can unlock the comp in case of an exception. Otherwise,
			# the user might be left with a locked comp.
			composition.StartUndo("Bake Animation")




			# step through frame range and record keys to a temporary dict (keys are
			# the corresponding input IDs)
			bakedkeys = {}
			for f in range(timestart, timeend+1):
				for inp in inputs.itervalues():
					try:
						bakedkeys[inp.ID][f] = inp[f]
					except KeyError:
						bakedkeys[inp.ID] = {}
						bakedkeys[inp.ID][f] = inp[f]




			# Overwrite inputs with fresh modifiers. This removes the existing animation.
			print "Baking keys of:"
			for inp in inputs.itervalues():
				print "- " + inp.Name
				# remove expression if necessary
				if tool[inp.ID].GetExpression() is not None:
					tool[inp.ID].SetExpression(None)
				# animate points with a 2d path and everything else with a bezier spline
				if inp.GetAttrs()["INPS_DataType"] == "Point":
					tool.AddModifier(inp.ID, "PolyPath")
				else:
					tool.AddModifier(inp.ID, "BezierSpline")




			# write recorded keys back to their respective inputs
			for f in range(timestart, timeend+1):
				for inp in inputs.itervalues():
					tool[inp.ID][f] = bakedkeys[inp.ID][f]




			# Only if the undo event is closed, it will show up in the menu.
			composition.EndUndo(True)
			print("done")
			
		finally:
			composition.Unlock()

	
# fin

