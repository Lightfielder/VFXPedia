#python

################################################################################
#
# Filename: 3dc_applink.py
#
# Description: 3D-Coat AppLink functionality for eyeon fusion
#
# 3D-Coat Home Page: http://www.3d-coat.com
#
# Version: 1.06
#
# Author: Ilia Zaslavsky <|> Email: vfxdomain@gmail.com <|> Web: http://flavors.me/vfxdomain
#
# Credits: Gwynne Reddick <|> Web: http://www.modonize.com
#
# Last Update: 13:30 08/12/10
#
################################################################################

import os
import sys

# variables needed to run through peyeon

# import PeyeonScript as eyeon
# fusion = eyeon.scriptapp("Fusion")
# comp = fusion.CurrentComp

# define os variables

SYSDRIVE = os.environ['SYSTEMDRIVE']
USERNAME = os.environ['USERNAME']
HOMEPATH = os.environ['HOMEPATH']

# define path to import.txt file

importfile = SYSDRIVE + HOMEPATH + '\\Documents\\3D-CoatV3\\Exchange\\import.txt'

# define path to export.txt file

exportfile = SYSDRIVE + HOMEPATH + '\\Documents\\3D-CoatV3\\Exchange\\export.txt'

# define path to textures.txt file

textures = SYSDRIVE + HOMEPATH + '\\Documents\\3D-CoatV3\\Exchange\\textures.txt'

# define export function

def ExportToCoat():

# put active tool into a variable and break if geometry node is not selected

	try:
		inp = comp.ActiveTool()
	except:
		print("Select 3D Geometry to Export")
		return

# create user dialog and get geometry saving directory input from user

	ret_path = comp.AskUser("Select directory for saving OBJ file", {1.0:{1.0:"dir", 2.0:"PathBrowse", 'Name':"Saving Directory and File Name (without extension)", 'Default':"C:\\Temp\\3dc_geo"}})

# Quit if the user canceled

	if ret_path == None:
		print("Canceled by user")

# define name and path of the 3D-Coat input (fusion output) OBJ file

	try:
		dir = ret_path["dir"]
		fus_geo = dir + ".obj"
		if not dir:
			print("Please Select Valid Path to Save OBJ File")
			return
	except:
		pass

# define name and path of the 3D-Coat output (fusion input) OBJ file

	coat_geo = str(fus_geo [0:-4]) + '_out' + str(fus_geo [-4:])

# create user dialog and get 3d-coat identifier input from user

	ret_cid = comp.AskUser("Select 3D-Coat ID (What to do in 3DC ?)", {1.0:{1.0:"CoatID", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"PerPixel Painting", 3.0:"MicroVertex Painting", 4.0:"Ptex Painting", 5.0:"UV Mapping", 6.0:"Voxel Sculpting", 7.0:"Primitive for Voxels", 8.0:"Reference Mesh", 9.0:"Pen Alpha", 10.0:"Retopo Mesh", 11.0:"AutoRetopo Mesh", 12.0:"Curve Profile", 13.0:"Open into Scene"}, 'Name':"3DC Identifier"}})

# create user dialog and get 3d-coat options input from user

	ret_opt = comp.AskUser("Select Options, Cancel to do it in 3D-Coat", {1.0:{1.0:"skip_in", 2.0:"Checkbox", 'Name':"Skip Import Dialog"}, 2.0:{1.0:"skip_out", 2.0:"Checkbox", 'Name':"Skip Export Dialog"}, 3.0:{1.0:"out_diff", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"YES", 3.0:"NO"}, 'Name':"Export Color"}, 4.0:{1.0:"out_spec", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"YES", 3.0:"NO"}, 'Name':"Export Specular"}, 5.0:{1.0:"out_norm", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"YES", 3.0:"NO"}, 'Name':"Export Normals"}, 6.0:{1.0:"out_disp", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"YES", 3.0:"NO"}, 'Name':"Export Disp."}, 7.0:{1.0:"pick_spos", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"YES", 3.0:"NO"}, 'Name':"Pick Source Pos"}, 8.0:{1.0:"pick_depth", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"YES", 3.0:"NO"}, 'Name':"Pick Depth L0"}, 9.0:{1.0:"coarse", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"YES", 3.0:"NO"}, 'Name':"Coarse Mesh"}, 10.0:{1.0:"disp_d", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"8 bits", 3.0:"16 bits", 4.0:"32 bits"}, 'Name':"Disp. Depth"}, 11.0:{1.0:"disp_n", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"GREYBASED", 3.0:"ZEROBASED", 4.0:"ZEROBASED_NORM", 5.0:"ZEROBASED_ABS"}, 'Name':"Disp. Norm"}, 12.0:{1.0:"disp_e", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"BMP", 3.0:"TGA", 4.0:"PNG", 5.0:"TIF", 6.0:"TIFF", 7.0:"EXR"}, 'Name':"Disp. Extension"}, 13.0:{1.0:"diff_e", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"TGA", 3.0:"BMP", 4.0:"PNG", 5.0:"JPG"}, 'Name':"Color Extension"}, 14.0:{1.0:"specnorm_e", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"TGA", 3.0:"BMP", 4.0:"PNG", 5.0:"JPG"}, 'Name':"Spec/Norm Ext."}, 15.0:{1.0:"out_res", 2.0:"Dropdown", 'Options':{1.0:"", 2.0:"LOW-POLY", 3.0:"MID-POLY"}, 'Name':"Export Res."}, 16.0:{1.0:"tex_path", 2.0:"PathBrowse", 'Name':"Textures Saving Path for 3D-Coat Output"}})

# print message to the console if both 3d-coat identifier and options dialogs being skipped

	if str(ret_cid) == "{'CoatID': 0.0}" and str(ret_opt) == "{'out_res': 0.0, 'disp_d': 0.0, 'diff_e': 0.0, 'tex_path': '', 'skip_in': 0.0, 'out_spec': 0.0, 'disp_n': 0.0, 'out_diff': 0.0, 'pick_depth': 0.0, 'coarse': 0.0, 'pick_spos': 0.0, 'out_norm': 0.0, 'disp_e': 0.0, 'out_disp': 0.0, 'skip_out': 0.0, 'specnorm_e': 0.0}":
		print("Please Select 3D-Coat ID, 3D-Coat Options or both")
		return

	if not ret_cid and str(ret_opt) == "{'out_res': 0.0, 'disp_d': 0.0, 'diff_e': 0.0, 'tex_path': '', 'skip_in': 0.0, 'out_spec': 0.0, 'disp_n': 0.0, 'out_diff': 0.0, 'pick_depth': 0.0, 'coarse': 0.0, 'pick_spos': 0.0, 'out_norm': 0.0, 'disp_e': 0.0, 'out_disp': 0.0, 'skip_out': 0.0, 'specnorm_e': 0.0}":
		print("Please Select 3D-Coat ID, 3D-Coat Options or both")
		return

	if not ret_opt and str(ret_cid) == "{'CoatID': 0.0}":
		print("Please Select 3D-Coat ID, 3D-Coat Options or both")
		return

	if not ret_cid and not ret_opt:
		print("Please Select 3D-Coat ID, 3D-Coat Options or both")
		return

# define 3d-coat identifier

	try:
		cid = ret_cid["CoatID"]
	except:
		cid = 0
	if (cid == 0):
		pass
	if (cid == 1):
		coatid = "[ppp]"
	if (cid == 2):
		coatid = "[mv]"
	if (cid == 3):
		coatid = "[ptex]"
	if (cid == 4):
		coatid = "[uv]"
	if (cid == 5):
		coatid = "[vox]"
	if (cid == 6):
		coatid = "[prim]"
	if (cid == 7):
		coatid = "[ref]"
	if (cid == 8):
		coatid = "[alpha]"
	if (cid == 9):
		coatid = "[retopo]"
	if (cid == 10):
		coatid = "[autopo]"
	if (cid == 11):
		coatid = "[curv]"
	if (cid == 12):
		coatid = "[3B]"

# define 3d-coat options

	try:
		skip_in = ret_opt["skip_in"]
	except:
		skip_in = 0
	if (skip_in == 0):
		pass
	if (skip_in == 1):
		skip_in_w = "[SkipImport]"

	try:
		skip_out = ret_opt["skip_out"]
	except:
		skip_out = 0
	if (skip_out == 0):
		pass
	if (skip_out == 1):
		skip_out_w = "[SkipExport]"

	try:
		tex_path = ret_opt["tex_path"]
		tex_path_w = "[TexOutput:" + tex_path + "]"
		if not tex_path:
			tex_path_w = None
	except:
		pass

	try:
		out_diff = ret_opt["out_diff"]
	except:
		out_diff = 0
	if (out_diff == 0):
		pass
	if (out_diff == 1):
		out_diff_w = "[ExportColor = 1]"
	if (out_diff == 2):
		out_diff_w = "[ExportColor = 0]"

	try:
		out_spec = ret_opt["out_spec"]
	except:
		out_spec = 0
	if (out_spec == 0):
		pass
	if (out_spec == 1):
		out_spec_w = "[ExportSpecular = 1]"
	if (out_spec == 2):
		out_spec_w = "[ExportSpecular = 0]"

	try:
		out_norm = ret_opt["out_norm"]
	except:
		out_norm = 0
	if (out_norm == 0):
		pass
	if (out_norm == 1):
		out_norm_w = "[ExportNormalmap = 1]"
	if (out_norm == 2):
		out_norm_w = "[ExportNormalmap = 0]"

	try:
		out_disp = ret_opt["out_disp"]
	except:
		out_disp = 0
	if (out_disp == 0):
		pass
	if (out_disp == 1):
		out_disp_w = "[ExportDispl = 1]"
	if (out_disp == 2):
		out_disp_w = "[ExportDispl = 0]"

	try:
		pick_spos = ret_opt["pick_spos"]
	except:
		pick_spos = 0
	if (pick_spos == 0):
		pass
	if (pick_spos == 1):
		pick_spos_w = "[PickSourcePositions = 1]"
	if (pick_spos == 2):
		pick_spos_w = "[PickSourcePositions = 0]"

	try:
		pick_depth = ret_opt["pick_depth"]
	except:
		pick_depth = 0
	if (pick_depth == 0):
		pass
	if (pick_depth == 1):
		pick_depth_w = "[PickDepthFromLayer0 = 1]"
	if (pick_depth == 2):
		pick_depth_w = "[PickDepthFromLayer0 = 0]"

	try:
		coarse = ret_opt["coarse"]
	except:
		coarse = 0
	if (coarse == 0):
		pass
	if (coarse == 1):
		coarse_w = "[CoarseMesh = 1]"
	if (coarse == 2):
		coarse_w = "[CoarseMesh = 0]"

	try:
		disp_d = ret_opt["disp_d"]
	except:
		disp_d = 0
	if (disp_d == 0):
		pass
	if (disp_d == 1):
		disp_d_w = "[DisplDepth = 8 bits]"
	if (disp_d == 2):
		disp_d_w = "[DisplDepth = 16 bits]"
	if (disp_d == 3):
		disp_d_w = "[DisplDepth = 32 bits]"

	try:
		disp_n = ret_opt["disp_n"]
	except:
		disp_n = 0
	if (disp_n == 0):
		pass
	if (disp_n == 1):
		disp_n_w = "[DisplNorm = GREYBASED]"
	if (disp_n == 2):
		disp_n_w = "[DisplNorm = ZEROBASED]"
	if (disp_n == 3):
		disp_n_w = "[DisplNorm = ZEROBASED_NORM]"
	if (disp_n == 4):
		disp_n_w = "[DisplNorm = ZEROBASED_ABS]"

	try:
		disp_e = ret_opt["disp_e"]
	except:
		disp_e = 0
	if (disp_e == 0):
		pass
	if (disp_e == 1):
		disp_e_w = "[DisplExt = BMP]"
	if (disp_e == 2):
		disp_e_w = "[DisplExt = TGA]"
	if (disp_e == 3):
		disp_e_w = "[DisplExt = PNG]"
	if (disp_e == 4):
		disp_e_w = "[DisplExt = TIF]"
	if (disp_e == 5):
		disp_e_w = "[DisplExt = TIFF]"
	if (disp_e == 6):
		disp_e_w = "[DisplExt = EXR]"

	try:
		diff_e = ret_opt["diff_e"]
	except:
		diff_e = 0
	if (diff_e == 0):
		pass
	if (diff_e == 1):
		diff_e_w = "[ColorFileExtension = TGA]"
	if (diff_e == 2):
		diff_e_w = "[ColorFileExtension = BMP]"
	if (diff_e == 3):
		diff_e_w = "[ColorFileExtension = PNG]"
	if (diff_e == 4):
		diff_e_w = "[ColorFileExtension = JPG]"

	try:
		specnorm_e = ret_opt["specnorm_e"]
	except:
		specnorm_e = 0
	if (specnorm_e == 0):
		pass
	if (specnorm_e == 1):
		specnorm_e_w = "[SpecNormExtension = TGA]"
	if (specnorm_e == 2):
		specnorm_e_w = "[SpecNormExtension = BMP]"
	if (specnorm_e == 3):
		specnorm_e_w = "[SpecNormExtension = PNG]"
	if (specnorm_e == 4):
		specnorm_e_w = "[SpecNormExtension = JPG]"

	try:
		out_res = ret_opt["out_res"]
	except:
		out_res = 0
	if (out_res == 0):
		pass
	if (out_res == 1):
		out_res_w = "[ExportResolution = LOW-POLY]"
	if (out_res == 2):
		out_res_w = "[ExportResolution = MID-POLY]"

# lock composition in fusion

	comp.Lock()

# define flow

	flow = comp.CurrentFrame.FlowView

# create FBX Exporter node

	geo_out = comp.ExporterFBX({})

# set FBX Exporter node's input to active tool

	geo_out.Input = inp

# set FBX Exporter node's format to OBJ

	geo_out.Format = 'Alias_OBJ'

# set FBX Exporter node's output path

	geo_out.Filename = fus_geo

# make FBX Exporter node active

	comp.SetActiveTool(geo_out)

# get composition render start/end

	ren_start = comp.GetAttrs('COMPN_RenderStartTime')
	ren_end = comp.GetAttrs('COMPN_RenderEndTime')

# render composition's first frame to run FBX Exporter

	comp.Render({'Start': 0, 'End': 0, 'Tool': geo_out, 'Wait': True})

# set composition render start/end back to the original values

	comp.SetAttrs({'COMPN_RenderStart': ren_start})
	comp.SetAttrs({'COMPN_RenderEnd': ren_end})

# unlock composition in fusion

	comp.Unlock()

# write input and output files path to import.txt file

	try:
		f = open(importfile, 'w')
		f.writelines( '%s' % fus_geo)
		f.writelines( '\n' '%s' % coat_geo)
	except:
		print("Can't Create import.txt File: no Exchange Directory / no Writing Access")
		return

# write 3d-coat identifiers to import.txt file

	try:
		f.writelines( '\n' '%s' % coatid)
	except:
		pass

# write 3d-coat options to import.txt file

	try:
		f.writelines( '\n' '%s' % skip_in_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % skip_out_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % out_diff_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % out_spec_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % out_norm_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % out_disp_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % pick_spos_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % pick_depth_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % coarse_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % disp_d_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % disp_n_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % disp_e_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % diff_e_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % specnorm_e_w)
	except:
		pass
	try:
		f.writelines( '\n' '%s' % out_res_w)
	except:
		pass
	try:
		if tex_path_w == None:
			return
		f.writelines( '\n' '%s' % tex_path_w)
	except:
		pass

# close import.txt file

	f.close()

# ============================================================================ #

# define import function

def ImportFromCoat():

# open export.txt file and break if is missing

	try:
		datafile = open(exportfile, 'r')
	except:
		print("export.txt file is missing")
		return

# open textures.txt file and break if is missing

	try:
		texfile = open(textures, 'r')
	except:
		print("textures.txt file is missing")
		return

# read path to 3d-coat output file specified in export.txt file

	scenefile = datafile.readline().rstrip()

# create a dictionary from textures.txt

	materials = {}

	while 1:
		material = texfile.readline().rstrip()
		if not material:
			break
		if material not in materials.keys():
			materials[material] = {}
		uvmap = texfile.readline().rstrip()
		if uvmap not in materials[material].keys():
			materials[material]['uvmap'] = uvmap
		type = texfile.readline().rstrip()
		if type not in materials[material].keys():
			if type.startswith('displacement'):
				# split the value off     
				type, dispval = type.split()
				# now we're going to add a new key to the dictionary for the displacement value
				materials[material]['dispvalue'] = float(dispval)/10
			materials[material][type] = texfile.readline().rstrip()

	texfile.close()

# lock composition in fusion

	comp.Lock()

# define flow

	flow = comp.CurrentFrame.FlowView

# define left and right views

	L_view = comp.GetPreviewList()["Left"]
	R_view = comp.GetPreviewList()["Right"]	

# create blinn material node

	mtl = comp.MtlBlinn({})

# select blinn material node

	flow.Select(mtl)

# set material node's position in the flow

	flow.SetPos(mtl, 0, 0)

# create FBX geometry node

	geo = comp.SurfaceFBXMesh({})

# select FBX geometry material node

	flow.Select(geo)

# view geometry node on the left view

	L_view.ViewOn(geo)

# set left view scale to 'Fit'

	L_view.View.SetScale(0)

# set 3D geometry node's position in the flow

	flow.SetPos(geo, 0, 3)

# load blinn material into 3D geometry node's material input

	geo.MaterialInput = mtl

# load 3d-coat output file into 3D geometry node's scene input

	geo.ImportFile = scenefile

# set name of 3D geometry node

	geo.ObjName = "3D-Coat Output"

# define variables for texture maps from textures.txt file

	for mat in materials.keys():

		if 'uvmap' in materials[mat].keys():
			uv = materials[mat]['uvmap']

		if 'color' in materials[mat].keys():
			diff = materials[mat]['color']
			# create loader for color texture map
			diff_loader = comp.Loader({'Clip' : diff})
			# select color texture loader node
			flow.Select(diff_loader)
			# set color texture loader position in the flow
			flow.SetPos(diff_loader, 1, 0)
			# create 2D texture node and load color texture
			diff_tex = comp.CreateTextureOperator({})
			# select color texture node
			flow.Select(diff_tex)
			# set color texture node's position in the flow
			flow.SetPos(diff_tex, 1, 3)
			diff_tex.Input = diff_loader
			# load color texture node into blinn material color input
			mtl({'Diffuse.Color.Material' : diff_tex})

		if 'specular' in materials[mat].keys():
			spec = materials[mat]['specular']
			# create loader for specular texture map
			spec_loader = comp.Loader({'Clip' : spec})
			# select specular texture loader node
			flow.Select(spec_loader)
			# set specular texture loader position in the flow
			flow.SetPos(spec_loader, 2, 0)
			# create 2D texture node and load specular texture
			spec_tex = comp.CreateTextureOperator({})
			# select specular texture node
			flow.Select(spec_tex)
			# set specular texture node's position in the flow
			flow.SetPos(spec_tex, 2, 3)
			spec_tex.Input = spec_loader
			# load specular texture node into blinn material specular inputs
			mtl({'Specular.Intensity.Material' : spec_tex, 'Specular.Exponent.Material' : spec_tex, 'Specular.Color.Material' : spec_tex})

		if 'normalmap' in materials[mat].keys():
			norm = materials[mat]['normalmap']
			# create loader for normals texture map
			norm_loader = comp.Loader({'Clip' : norm})
			# select normals texture loader node
			flow.Select(norm_loader)
			# set normals texture loader position in the flow
			flow.SetPos(norm_loader, 3, 0)
			# create bumpmap node and load normals texture
			norm_tex = comp.BumpMap({})
			# select bumpmap node
			flow.Select(norm_tex)
			# set bumpmap node's position in the flow
			flow.SetPos(norm_tex, 3, 3)
			norm_tex.Input = norm_loader
			# set source image type to bumpmap
			norm_tex.SourceImageType = 1
			# load bumpmap texture node into blinn material bumpmap input
			mtl({'Bumpmap.Material' : norm_tex})

		if 'dispvalue' in materials[mat].keys():
			dscl = materials[mat]['dispvalue']

		if 'displacement' in materials[mat].keys():
			disp = materials[mat]['displacement']
			# create loader for displacement texture map
			disp_loader = comp.Loader({'Clip' : disp})
			# select displacement texture loader node
			flow.Select(disp_loader)
			# set displacement texture loader position in the flow
			flow.SetPos(disp_loader, 4, 0)
			# create 3D displacement node and load displacement texture
			disp_tex = comp.Displace3D({})
			# select displacement node
			flow.Select(disp_tex)
			# set displacement node's position in the flow
			flow.SetPos(disp_tex, 4, 3)
			disp_tex.Input = disp_loader
			# load geometry into displacement node's scene input
			disp_tex.SceneInput = geo
			# set displacement scale
			disp_tex.Scale = dscl
			# set displacement bias
			disp_tex.Bias = -0.5
			# view displacement node on the left view
			L_view.ViewOn(disp_tex)
			# set left view scale to 'Fit'
			L_view.View.SetScale(0)

# unlock composition in fusion

	comp.Unlock()

# close export.txt file after loading 3dcoat output file

	datafile.close()

# close textures.txt file after loading textures

	texfile.close()

# delete export.txt file after loading 3dcoat output file

	os.remove(exportfile)

# delete textures.txt file after loading 3dcoat textures

	os.remove(textures)

# send CTRL + G keypress to fusion to group selected nodes

	#import win32com.client as comclt
	#wsh = comclt.Dispatch("WScript.Shell")
	#wsh.AppActivate ('Fusion')
	#comp.CurrentFrame.SwitchMainView('FlowView')
	#wsh.SendKeys("^g")

# create user dialog and get import/export selection input from user

ret_io = comp.AskUser("Select Import or Export Checkbox", {1.0:{1.0:"out_box", 2.0:"Checkbox", 'Name':"Export To 3D-Coat"}, 2.0:{1.0:"in_box", 2.0:"Checkbox", 'Name':"Import From 3D-Coat"}})

# Quit if the user canceled

if ret_io == None:
    print("Canceled by user")

# run import or export function depending on user input

try:
	output = ret_io["out_box"]
	input = ret_io["in_box"]
	if (output == 1) and (input == 0):
		ExportToCoat()
	if (input == 1) and (output == 0):
		ImportFromCoat()
	if (output == 0) and (input == 0):
		print("Please Select Import or Export Checkbox")
	if (output == 1) and (input == 1):
		print("Please Don't Select Import and Export Checkboxes Simultaneously!")
except:
	pass
