################################################################################
#
# Description: 3D-Coat AppLink functionality for Eyeon Fusion 6
#
# Version: 1.06
#
# Author: Ilia Zaslavsky <|> Email: vfxdomain@gmail.com <|> Web: http://flavors.me/vfxdomain
#
# Credits: Gwynne Reddick <|> Web: http://www.modonize.com
#
# Last Update: 13:30 08/12/10
#
# 3D-Coat Home Page: http://www.3d-coat.com
#
################################################################################

Installation:

Unzip the archive.

Copy 3dc_applink.py file to your Fusion install folder\Scripts\Comp, the path is usually: 

C:\Program Files\eyeon\Fusion 6.1\Scripts\Comp
or
C:\Program Files (x86)\eyeon\Fusion 6.1\Scripts\Comp

Restart Fusion.

################################################################################

Usage:

In fusion, make geometry node (usually FBXMesh3D or Shape3D) you want to edit in 3D-Coat 
active (selected and active is not the same thing, selected node is blue while active is 
yellow, so make sureto make geo node active in fusion), then run AppLink UI by hitting 
Script -> 3dc_applink.py in Fusion menu bar. Select "Import from 3D-Coat" or 
"Export to 3D-Coat" checkbox and hit "OK".

If you choose "Export to 3D-Coat", saving dialog should pop, choose location and name of 
the output file (without extension, .obj is set automatically), choose 3D-Coat Identifier
in the next dialog window, then in the last "Options" dialog you can choose to skip
importing and exporting dialogs in 3D-Coat and pre-select some options. This last step 
is optional, you can cancel this window and set all needed options inside 3D-Coat.
Also you should know that pre-selecting this options and skipping 3D-Coat import 
and/or export dialogs should work only in 3D-Coat version 3.5.06 and up.

After exporting geometry from Fusion via AppLink script, run 3D-Coat 
(or bring the focus to it's window if 3D-Coat was started earlier), a dialog
with options based on your "3D-Coat Identifier" selection in AppLink script should pop up.
Set needed options, hit "OK" and edit imported mesh to your heart content, using 3D-Coat's
rich toolbox for Texture Painting, UV Editing etc. When done, select "File" -> 
"Open in Originall App" from 3D-Coat main Menu.

Now go back to Fusion, run AppLink script and select 'Import from 3D-Coat' checkbox to
bring edited mesh with textures and maps created in 3D-Coat back to Fusion. A network
of nodes should be created, with color, specular, normals and displacement maps loaders,
2D Texture/Displace 3D/BumpMap nodes for this loaders, assigned to the correct inputs
of the Blinn material, which is connected to the material input of the 3D mesh node.
You can repeat the whole process as many times as needed.

################################################################################

!!!--- Note about Displacement ---!!!

Current version of Fusion does not allows to tesselate imported geometry. 
When using Displace 3D, keep in mind that it will only displace existing vertices 
and will not tessellate objects. To obtain a more detailed displacement, increase 
the Subdivision amount for the geometry that is being displaced (available only for 
Shape3D nodes, if you're using geometry imported via FBXMesh3D node make sure to 
pre-tesselate it outside of Fusion if needed).

################################################################################
