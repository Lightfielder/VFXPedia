# ; Send To Fusion
#----------------------------------------------------------------------
# Copyright (c) 2014, Stefan Ihringer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#----------------------------------------------------------------------

"""
Send To Fusion - part of the Syntheyes/Fusion Bridge

This script sends the result of your Syntheyes project to a running instance of Fusion.
It can either create a new comp or update existing cameras, point clouds and so on.

The script tries to mimick the flow that is created by the regular Fusion exporter. Differences:
- meshes, object-relative point clouds, lights and far points are currently not created.
- if a new loader needs to be created, it will mimick the frame range of your Syntheyes project
  (first frame 0 or 1 or matching actual image sequence numbers). If a loader already exists,
  it will be updated, taking into account any frame offset or trimming.
- only image sequences are currently supported (no quicktime/avi)

Syntheyes 2013.11 Pro or later required! (Intro license doesn't support Python scripting)
To install, copy this file to your user scripts folder (can be reached via Syntheyes' scripts menu)
and make sure the correct path to your python.exe is set up in the preferences.
"""

VERSION = "1.0beta - 2014-01-26"

# TODO:
# abort if 3D planar trackers are using different fov values
# low priority ideas:
# - workarea option for new loaders (via comp:AskUser?)
# - export meshes
# - 2D planar trackers?


import re
import glob
import math
import subprocess
import os.path
from os import system
from time import sleep, strftime
import SyPy
import PeyeonScript as eyeon

hlev = None     # global variables for connecting to Syntheyes and Fusion
fu = None
comp = None
bias = 0        # Fusion's timeline differs from Syntheyes by this many frames


def NM(orinm):
    """
    Convert the name of a Syntheyes object for use as a tool in Fusion.

    This removes spaces and turns anything else problematic into underscores.
    """
    newname = re.sub(" ", "", orinm)
    return re.sub(r"\W", "_", newname)


def find_fusion():
    """Look for Fusion.exe and return handle to Fusion instance."""
    fu = eyeon.scriptapp("Fusion")
    if not fu:
        # Fusion isn't running. autodetection:
        for p1 in ("C:\\Program Files\\eyeon\\", "C:\\Program Files (x86)\\eyeon\\"):
            for p2 in ("Fusion 6.4", "Fusion 6.31", "Fusion 6.3"):
                executable = os.path.join(p1,p2,"Fusion.exe")
                if os.path.isfile(executable):
                    # found Fusion.exe: launch it
                    print("connecting to %s ." % p2),
                    subprocess.Popen({executable}, close_fds=True, cwd=os.path.join(p1,p2))
                    for i in range(0, 20):
                        sleep(1)
                        fu = eyeon.scriptapp("Fusion")
                        if fu is not None:
                            print "OK",
                            break
                        print('.'),
                    print "" 
                    return fu
    return fu


def get_footage_basename(footage):
    """Split extension and frame number from an image sequence file name. Result may end with a dot."""
    s_dir, s_base = os.path.split(footage)
    rexp = re.match(r"(?P<base>.+?)(?P<fnum>\d*)(?P<ext>\.[a-z]+)$", s_base, re.IGNORECASE)
    try:
        return os.path.join(s_dir, rexp.group('base'))
    except ValueError:
        # rexp didn't match or no frame number found...
        return footage


def get_footage_initialframe(footage):
    """Determine the number of the first frame of an image sequence."""
    s_ext = os.path.splitext(os.path.basename(footage))[1]
    firstframe = None
    for f in glob.iglob(get_footage_basename(footage) + "*" + s_ext):
        s_base = os.path.split(f)[1]
        rexp = re.match(r"(?P<base>.+?)(?P<fnum>\d*)(?P<ext>\.[a-z]+)$", s_base, re.IGNORECASE)
        try:
            fnum = int(rexp.group('fnum'))
            if firstframe is None or fnum < firstframe:
                firstframe = fnum
        except ValueError:
            # regexp didn't match
            continue
    return firstframe


def get_tool_position(tool):
    """Returns x and y coordinates of the specified tool, rounded to the next integer."""
    tmp = comp.CurrentFrame.FlowView.GetPosTable(tool)
    return round(tmp[1.0]), round(tmp[2.0])


def add_tool_modifiers(fuTool):
    """Create animation curves for the tool's Transform3DOp values."""
    try:
        fuTool.AddModifier("Transform3DOp.Translate.X", "BezierSpline")
        fuTool.AddModifier("Transform3DOp.Translate.Y", "BezierSpline")
        fuTool.AddModifier("Transform3DOp.Translate.Z", "BezierSpline")
        fuTool.AddModifier("Transform3DOp.Rotate.X", "BezierSpline")
        fuTool.AddModifier("Transform3DOp.Rotate.Y", "BezierSpline")
        fuTool.AddModifier("Transform3DOp.Rotate.Z", "BezierSpline")
    except:
        pass


def update_tool_modifiers(fuTool, f, trans):
    """
    Set transformation keyframes on fuTool at frame f.

    'trans' is a list of 6 values as retrieved by the get_transformation_values() function below.
    """
    try:
        fuTool.Transform3DOp.Translate.X[f] = trans[0]
        fuTool.Transform3DOp.Translate.Y[f] = trans[1]
        fuTool.Transform3DOp.Translate.Z[f] = trans[2]
        fuTool.Transform3DOp.Rotate.X[f] = trans[3]
        fuTool.Transform3DOp.Rotate.Y[f] = trans[4]
        fuTool.Transform3DOp.Rotate.Z[f] = trans[5]
    except:
        pass


def remove_tool_modifiers(fuTool, what):
    """Removes keys from either Translation or Rotation groups."""
    try:
        if what == "Translate":
            fuTool.Transform3DOp.Translate.X = None
            fuTool.Transform3DOp.Translate.Y = None
            fuTool.Transform3DOp.Translate.Z = None
        elif what == "Rotate":
            fuTool.Transform3DOp.Rotate.X = None
            fuTool.Transform3DOp.Rotate.Y = None
            fuTool.Transform3DOp.Rotate.Z = None
    except:
        pass


def get_transformation_values(ob):
    """
    Turn translation and rotation values of a SyObj into a list.

    The elements of the list are x,y,z,rx,ry,rz.
    Angles are in degrees and all values are rounded to 6 decimals.
    """
    if ob.Type() == "TRK" and ob.isPlanar3D:
        # it's a 3D planar tracker
        return list(round(x, 6) for x in (ob.wplnx, ob.wplny, ob.wplnz, ob.wplnrx, ob.wplnry, ob.wplnrz))
    else:
        # assume it's a SyObj
        return list(round(x, 6) for x in (ob.x, ob.y, ob.z, ob.rx, ob.ry, ob.rz))


def do_camera(fuCam, syShot = None, syCam = None):
    """
    Animate an existing Camera3D tool.
    
    fuCam is a handle to Fusion's camera, while syCam is the camera object in Syntheyes.
    syShot is the shot object.
    """
    global bias
    relScnDst = 3.0         # distance to image plane, hardcoded for now
    fuCam.SetAttrs({'TOOLB_Locked': False})
    fuCam.FilmGate = "User"
    fuCam.ApertureW = syShot.effBackPlateWidth / 25.4
    fuCam.ApertureH = syShot.effBackPlateWidth / syShot.aspect / 25.4
    fuCam.IDepth = syCam.worldSize * relScnDst
    fuCam.PerspFarClip = syCam.worldSize * (relScnDst + 1)
    fuCam.SurfacePlaneInputs.Lighting.IsAffectedByLights = False
    fuCam.AovType = 1       # horizontal
    fuCam.FLength = syCam.fl

    # bake fov keys
    fuCam.AddModifier("AoV", "BezierSpline")
    lens_is_fixed = True
    first_key = None
    for f in range(int(syShot.start), int(syShot.stop)+1):
        hlev.SetSzlFrame(f)
        fuCam.AoV[f+bias] = syCam.fov
        if first_key is None:
            first_key = syCam.fov
        else:
            if abs(syCam.fov - first_key) > 0.0001:
                lens_is_fixed = False
    if lens_is_fixed:
        fuCam.AoV = None
        print " * fixed AoV (%f)" % syCam.fov

    # bake translation/rotation keys
    add_tool_modifiers(fuCam)
    is_stationary = True    # does camera move?
    is_fixated = True       # does camera rotate?
    first_key = None
    print " * baking key frames"
    for f in range(int(syShot.start), int(syShot.stop)+1):
        hlev.SetSzlFrame(f)
        trans = get_transformation_values(syCam)
        update_tool_modifiers(fuCam, f+bias, trans)
        if first_key is None:
            first_key = trans
        else:
            if trans[:3] != first_key[:3]:
                is_stationary = False
            if trans[3:] != first_key[3:]:
                is_fixated = False
    # remove animation if it turned out that the camera doesn't move or rotate
    if is_stationary:
        print " * camera is stationary"
        remove_tool_modifiers(fuCam, "Translate")
    if is_fixated:
        print " * camera is fixated"
        remove_tool_modifiers(fuCam, "Rotate")
    fuCam.Comments = os.path.splitext(os.path.basename(syShot.nm))[0]
    fuCam.SetAttrs({'TOOLB_Locked': True})


def count_valid_trackers(syCam, count_far = False):
    """Return number of solved, exportable trackers."""
    pcc = 0
    for tk in syCam.Trackers():
        if tk.isSolved and tk.isExported:
            if(count_far and tk.isFar) or (not count_far and not tk.isFar):
                pcc += 1
    return pcc


def do_pointcloud(fuCloud, syCam = None, far_cloud = False):
    """
    Update a PointCloud3D tool with syCam's trackers.

    This requires a workaround, because Fusion doesn't allow to add/remove points. The whole
    tool needs to be copied to a settings table, modified and pasted back. This function
    expects a handle to a PointCloud3D and will return the handle to the new PointCloud3D.
    syCam is a handle to the Syntheyes camera object.
    TODO: implement far point cloud.
    """
    cloud_settings = comp.CopySettings(fuCloud)
    pos_dict = {}
    i = 0
    for tk in syCam.Trackers():
        if tk.isSolved and tk.isExported:
            if (far_cloud and tk.isFar) or (not far_cloud and not tk.isFar):
                pos_dict[i] = {1.0: tk.ox, 2.0: tk.oy, 3.0: tk.oz, 4.0: NM(tk.nm), '__flags': 256L}
                i += 1
    cloud_settings["Tools"][fuCloud.Name]["Positions"] = pos_dict
    # remember 3d inputs and all connected downstream tools
    x, y = get_tool_position(fuCloud)
    try:
        connectIn = fuCloud.SceneInput.GetConnectedOutput()
    except TypeError:
        connectIn = None
    connectOut = {}
    for inp in fuCloud.Output.GetConnectedInputs():
        connectOut.append(inp)
    # replace point cloud
    fuCloud.Delete()
    comp.SetActiveTool(None)
    comp.Paste(cloud_settings)
    fuCloud = comp.FindTool(NM(syCam.nm)+"Cloud3D")
    comp.CurrentFrame.FlowView.SetPos(fuCloud, x, y)
    # restore connections
    # TODO: test this!
    if connectIn:
        fuCloud.SceneInput.ConnectTo(connectIn)
    for inp in connectOut:
        inp.ConnectTo(fuCloud)
    print " * %d trackers" % i
    return fuCloud


def do_object(fuLoc, syObjct = None, syShot = None):
    """
    Update a moving object which is represented by a Locator3D.

    Use the regular Fusion export script if you also need meshes and point clouds for each object.
    """
    global bias
    # bake translation/rotation keys
    add_tool_modifiers(fuLoc)
    is_stationary = True
    is_fixated = True
    first_key = None
    print " * baking key frames"
    for f in range(int(syShot.start), int(syShot.stop)+1):
        hlev.SetSzlFrame(f)
        trans = get_transformation_values(syObjct)
        update_tool_modifiers(fuLoc, f+bias, trans)
        if first_key is None:
            first_key = trans
        else:
            if trans[:3] != first_key[:3]:
                is_stationary = False
            if trans[3:] != first_key[3:]:
                is_fixated = False
    # remove animation if it turned out that the image plane doesn't move or rotate
    if is_stationary:
        print " * object is stationary"
        remove_tool_modifiers(fuLoc, "Translate")
    if is_fixated:
        print " * object is fixated"
        remove_tool_modifiers(fuLoc, "Rotate")
    # print information on meshes that were skipped
    for m in syObjct.Meshes():
        print " * skipping %s (meshes not supported yet)" % m.nm


def do_planartracker3d(fuXf3d, fuPlane3d, syTrack = None, syShot = None):
    """
    Update a 3D planar tracker which consists of an image plane and a Transform3D tool.

    syTrack is a handle for the planar tracker and syShot for the shot object.
    """
    global bias
    fuPlane3d.SurfacePlaneInputs.Lighting.IsAffectedByLights = 0
    fuPlane3d.Transform3DOp.ScaleLock = 1
    fuPlane3d.Transform3DOp.Scale.X = syTrack.wplnwidth
    fuPlane3d.Transform3DOp.Scale.Y = syTrack.wplnheight
    fuPlane3d.Transform3DOp.Scale.Z = 1

    # bake translation/rotation keys
    add_tool_modifiers(fuXf3d)
    is_stationary = True
    is_fixated = True
    first_key = None
    print " * baking key frames"
    for f in range(int(syShot.start), int(syShot.stop)+1):
        hlev.SetSzlFrame(f)
        trans = get_transformation_values(syTrack)
        # rotate Transform3D by 90 degrees around X so the ImagePlane3D doesn't need rotation
        trans[3] -= 90
        update_tool_modifiers(fuXf3d, f+bias, trans)
        if first_key is None:
            first_key = trans
        else:
            if trans[:3] != first_key[:3]:
                is_stationary = False
            if trans[3:] != first_key[3:]:
                is_fixated = False
    # remove animation if it turned out that the image plane doesn't move or rotate
    if is_stationary:
        print " * plane is stationary"
        remove_tool_modifiers(fuXf3d, "Translate")
    if is_fixated:
        print " * plane is fixated"
        remove_tool_modifiers(fuXf3d, "Rotate")


def main():
    """Main export function."""

    tomergelist = []        # list of all tools that are fed into a final Merge3D
    selectlist = []         # list of tools that will be selected (all newly created tools)

    scene = hlev.Scene()
    maincam = hlev.Active().cam
    shot = maincam.shot
    hlev.SetSzlFrame(shot.start)
    footage = shot.imageName
    if footage is None:
        raise RuntimeError("No image sequence has been loaded (QuickTime/AVI is currently not supported).")
    initialframe = get_footage_initialframe(footage)

    # set up the composition
    global comp
    global bias
    comp = fu.GetCurrentComp()
    if comp is None:
        # no open composition found: create a new one (range will be set up later)
        comp = fu.NewComp()
        comp.SetPrefs("Comp.Info.Comments", "Source: %s\r\nCreated: %s\r\n" % (scene.sourceFile, strftime("%a, %b %d, %Y %I:%M:%S %p")))
    flow = comp.CurrentFrame.FlowView

    comp.StartUndo("Syntheyes Update")
    comp.Lock()

    try:
        # find loader with matching footage. In Fusion, you can specify any frame number in a Loader so
        # the comparison needs to be on the path and filename without extension and frame number.
        shot_loader = None
        for i, ld in comp.GetToolList(False, "Loader").items():
            clip = ld.Clip[comp.TIME_UNDEFINED]
            if get_footage_basename(clip).lower() == get_footage_basename(footage).lower():
                shot_loader = ld
                break
        if not shot_loader:
            # no suitable Loader: create a new one
            # set up frame range based on Syntheyes project (TODO: offer options like in Fusion->Syntheyes script)
            if scene.matchFrameNumbers:
                bias = shot.frameFirstOffset
            else:
                bias = scene.startFrame
            print "Syntheyes frame numbering starts at %d" % bias
            comp.SetActiveTool(None)
            comp.SetAttrs({'COMPN_GlobalStart': bias+shot.start, 'COMPN_GlobalEnd': bias+shot.stop, 'COMPN_RenderStart': bias+shot.start, 'COMPN_RenderEnd': bias+shot.stop})
            comp.CurrentTime = bias+shot.start

            autobrowse = fu.GetPrefs("Global.UserInterface.AutoClipBrowse")
            fu.SetPrefs("Global.UserInterface.AutoClipBrowse", False)
            shot_loader = comp.AddTool("Loader", -32768, -32768)
            fu.SetPrefs("Global.UserInterface.AutoClipBrowse", autobrowse)
            shot_loader.SetAttrs({'TOOLS_Name': NM(maincam.nm)+"Shot"})
            shot_loader.Clip = footage
            # tool has probably been placed at non-integer position. correct this...
            flow.SetPos(shot_loader, *get_tool_position(shot_loader))
            # Syntheyes can start a shot at any frame number within an image sequence. Fusion, however, will always
            # start its clips with the lowest number in a sequence so the trimming value might have to be increased.
            shot_loader.ClipTimeStart = shot.start + (shot.frameFirstOffset - shot_loader.GetAttrs()['TOOLIT_Clip_InitialFrame'][1])
            selectlist.append(shot_loader)
            print "created new loader %s" % shot_loader.Name
        else:
            # re-use existing Loader. Its frame range will not be changed. Instead, all keyframes that will
            # be created are adjusted to the Loader's trimming and offset ("bias" variable)
            # step 1: where would the clip's frame #0 be on Fusion's timeline?
            # step 2: where would the clip's frame #0 be in Syntheyes?
            lAttrs = shot_loader.GetAttrs()
            fuZero = lAttrs['TOOLNT_Clip_Start'][1] - lAttrs['TOOLIT_Clip_TrimIn'][1] - lAttrs['TOOLIT_Clip_InitialFrame'][1]
            syZero = -shot.frameFirstOffset
            bias = fuZero - syZero
            print "re-using loader %s" % ld.Name

        print " * clip in: %d" % shot_loader.GetAttrs()['TOOLNT_Clip_Start'][1]
        print " * trim in: %d" % shot_loader.GetAttrs()['TOOLIT_Clip_TrimIn'][1]

        # keep track of tool coordinates
        node_x0, node_y0 = get_tool_position(shot_loader)
        node_x = node_x0 + 2
        node_y = node_y0
        comp.SetActiveTool(None)

        # Do camera. First, look for one with the correct name. TODO: If none can be found, see if
        # a camera has the footage in its comment field or if it is connected to the Loader.
        shot_camera = comp.FindTool(NM(maincam.nm))
        if not shot_camera:
            # no camera found: create a new one
            shot_camera = comp.AddTool("Camera3D", node_x, node_y)
            shot_camera.SetAttrs({'TOOLS_Name': NM(maincam.nm), 'TOOLB_NameSet': True})
            shot_camera.ImageInput.ConnectTo(shot_loader.Output)
            selectlist.append(shot_camera)
            print "created new camera %s:" % shot_camera.Name
        else:
            print "updating camera %s:" % shot_camera.Name
        # make sure camera is always connected to the right loader
        shot_camera.ImageInput.ConnectTo(shot_loader.Output)
        do_camera(shot_camera, syShot = shot, syCam = maincam)
        # TODO: camera meshes

        # Do point cloud
        # TODO: far point cloud
        if count_valid_trackers(maincam) > 0:
            node_y += 3
            pcloud = comp.FindTool(NM(maincam.nm)+"Cloud3D")
            if not pcloud:
                pcloud = comp.AddTool("PointCloud3D", node_x, node_y)
                pcloud.SetAttrs({'TOOLS_Name': NM(maincam.nm)+"Cloud3D", 'TOOLB_NameSet': True})
                print "created new point cloud %s:" % pcloud.Name
                pcloud = do_pointcloud(pcloud, syCam = maincam)
                tomergelist.append(pcloud)
                selectlist.append(pcloud)
            else:
                print "updating point cloud %s:" % pcloud.Name
                pcloud = do_pointcloud(pcloud, syCam = maincam)
        else:
            print "no exportable trackers, skipping point cloud creation"

        # moving objects (just Locator3Ds for now, use regular export script for meshes / point cloud)
        for objct in hlev.Objects():
            if objct.cam == maincam and objct != maincam:
                node_y += 3
                locator = comp.FindTool(NM(objct.nm)+"Base")
                if not locator:
                    # no locator found: create a new one
                    locator = comp.AddTool("Locator3D", node_x, node_y)
                    locator.SetAttrs({'TOOLS_Name': NM(objct.nm)+"Base", 'TOOLB_NameSet': True})
                    tomergelist.append(locator)
                    selectlist.append(locator)
                    print "created new object locator %s:" % locator.Name
                else:
                    print "updating moving object locator %s:" % locator.Name
                do_object(locator, syObjct = objct, syShot = shot)

        # TODO: lights
        # 3D planar trackers. They consist of a static ImagePlane3D and a Transform3D that holds the keyframes.
        # TODO: make sure they all have the same FoV
        for tk in maincam.Trackers():
            if tk.isExported and tk.isPlanar3D:
                node_y += 3
                xf3d = comp.FindTool(NM(tk.nm))
                imgplane3d = comp.FindTool(NM(tk.nm)+"Plane")
                if not xf3d or not imgplane3d:
                    # no planar tracker tools found: create new transform and image plane
                    imgplane3d = comp.AddTool("ImagePlane3D", node_x - 2, node_y)
                    imgplane3d.SetAttrs({'TOOLS_Name': NM(tk.nm)+"Plane", 'TOOLB_NameSet': True})
                    xf3d = comp.AddTool("Transform3D", node_x, node_y)
                    xf3d.SetAttrs({'TOOLS_Name': NM(tk.nm), 'TOOLB_NameSet': True})
                    xf3d.SceneInput.ConnectTo(imgplane3d)
                    tomergelist.append(xf3d)
                    selectlist.append(xf3d)
                    selectlist.append(imgplane3d)
                    print "created new planar tracker %s" % tk.nm
                else:
                    print "updating planar tracker %s" % tk.nm
                do_planartracker3d(xf3d, imgplane3d, syTrack = tk, syShot = shot)

        # TODO: non-parented meshes
        # TODO: extra points
        # create merge and renderer for whole 3D scene if more than one new tool has been spawned
        if len(tomergelist) > 0:
            # camera will always be merged first even if an existing Camera3D was updated
            tomergelist.insert(0, shot_camera)
            node_x += 2
            node_y = (node_y + node_y0) / 2
            the_merge = comp.AddTool("Merge3D", node_x, node_y)
            the_merge.SetAttrs({'TOOLS_Name': NM(maincam.nm)+"Scene", 'TOOLB_NameSet': True})
            for i,t in enumerate(tomergelist, start=1):
                the_merge["SceneInput%d" % i].ConnectTo(t)
                flow.Select(t, True)
            the_renderer = comp.AddTool("Renderer3D", node_x + 2, node_y)
            the_renderer.SetAttrs({'TOOLS_Name': NM(maincam.nm)+"Renderer", 'TOOLB_NameSet': True})
            the_renderer.Width = shot.width
            the_renderer.Height = shot.height
            the_renderer.PixelAspect = {1.0: shot.pixasp, 2.0: 1.0}
            the_renderer.SceneInput.ConnectTo(the_merge)
            # select all new tools so they can be moved/deleted immediately
            flow.Select()
            for t in selectlist:
                flow.Select(t, True)
            flow.Select(the_merge, True)
            flow.Select(the_renderer, True)
            print "created scene merge and renderer"
        else:
            print "no new tools added, skipping Renderer3D creation"
            comp.SetActiveTool(shot_loader)

    finally:
        comp.EndUndo(True)
        comp.Unlock()
    # --- main() end ---


try:
    print "-----------------------------------------------------------------------------"
    print "Send 2 Fusion version %s" % VERSION
    print "-----------------------------------------------------------------------------\n"
    # perform initial checks, then launch main function
    hlev = SyPy.SyLevel()
    rv = hlev.OpenExisting()
    if not rv:
        raise RuntimeError("Can't connect to Syntheyes.\nPlease start this script from the Syntheyes user interface.")
    # we want Y-Up coordinates and XYZ rotation order
    hlev.SetSzlAxisMode(1)
    hlev.SetSzlRotOrder(1)

    # connect to Fusion or launch it
    fu = find_fusion()
    if not fu:
        raise RuntimeError("Couldn't start Fusion or it took too long.\nTry running this script when Fusion is already open in the background.")
    main()

except RuntimeError as e:
    print "Error: %s" % e
except Exception as e:
    print "%s: %s" % (e.__class__.__name__, e)
finally:
    print ""
    system("pause")
