#----------------------------------------------------------------------
# Copyright (c) 2014, Stefan Ihringer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#----------------------------------------------------------------------

## version 1.0beta, 2014-01-19

"""
Track This! - part of the Syntheyes/Fusion Bridge

This tool script has to be executed on a Loader. It will open the selected footage
in Syntheyes, set up a project and optionally start tracking it immediately.
Syntheyes 2013.11 Pro or later required! (Intro license doesn't support Python scripting)
"""

## Options:
# Port and pin for Syntheyes.
SYPORT = 65432
SYPIN  = "SyntheyesFusion"
# TODO: Custom path to Syntheyes. None for default (C:\Program Files\Andersson Technologies LLC\SynthEyes)
#SYPATH = None
# Print verbose info to the console?
VERBOSE = False

import os.path
import re
import SyPy

hlev = SyPy.SyLevel()


def popupOptions(opts = {}):
    """Popup options dialog and return results."""

    trimin    = int(tool.GetAttrs()['TOOLIT_Clip_TrimIn'][1])
    trimout   = int(tool.GetAttrs()['TOOLIT_Clip_TrimOut'][1])
    cliplength   = int(tool.GetAttrs()['TOOLIT_Clip_Length'][1])
    initialframe = int(tool.GetAttrs()['TOOLIT_Clip_InitialFrame'][1])
    clipname  = os.path.splitext(os.path.basename(tool.GetAttrs()['TOOLST_Clip_Name'][1]))[0]

    # figure out a default Syntheyes file name based on the comp's name and the footage
    defaultSNI = os.path.splitext(comp.GetAttrs()['COMPS_Name'])[0]
    if defaultSNI:
        defaultSNI = defaultSNI + "_"
    defaultSNI = defaultSNI + clipname
    if defaultSNI:
        defaultSNI = "Comp:%s.sni" % defaultSNI

    dialog = {}
    n = 0
    if not (trimin == 0 and trimout == cliplength - 1):
        workareaOpts =  {1: "whole clip (%d-%d)" % (initialframe, initialframe+cliplength-1), 2: "trimmed range (%d-%d)" % (initialframe+trimin, initialframe+trimout)}
        dialog[1] = {1: 'workarea',  2: 'Dropdown', 'Name': 'What to Track',  'Options': workareaOpts, 'Default': opts.setdefault('workarea', 0)}
        n = 1

    dialog[n+1] = {1: 'aspect',     2: 'Slider',     'Name': 'Custom Image Aspect (0 = autodetect)', 'Min': 0, 'MaxScale': 2, 'Default': opts.setdefault('aspect',0) }
    dialog[n+2] = {1: 'filmback',   2: 'Dropdown',   'Name': 'Film Back Width', 'Options': {1: "Default (24.892 mm)", 2: "Arri Alexa (23.760 mm)", 3: "RED One 4K (22.11 mm)"}, 'Default': opts.setdefault('filmback',0) }
    dialog[n+3] = {1: 'autotrack',  2: 'Checkbox',   'Name': 'Auto-Track Footage', 'Default': opts.setdefault('autotrack', 0) }
    dialog[n+4] = {1: 'savesni',    2: 'Checkbox',   'Name': 'Save .sni project', 'Default': opts.setdefault('savesni', 0) }
    dialog[n+5] = {1: 'snifile',    2: 'FileBrowse', 'Name': 'Syntheyes Project File Name', 'Save': True, 'Default': opts.setdefault('snifile', defaultSNI) }

    # show dialog box
    ret = composition.AskUser("Track in Syntheyes (beta)", dialog)
    if ret:
        ret.setdefault('workarea', 0)
    return ret


def fuMessage(msg):
    """Switch to console to print an important message."""

    composition.GetFrameList()[1].SwitchMainView('ConsoleView')
    print "\n----------------------------------------------------------------------------------------"
    print msg
    print "----------------------------------------------------------------------------------------\n"


def connectToSyntheyes():
    """Launch or Re-Use a Syntheyes instance."""

    global hlev
    if VERBOSE:
        print "Trying to find Syntheyes on port %d..." % SYPORT
    rv = hlev.OpenExisting(SYPORT, SYPIN)
    if rv:
        # if re-using an existing instance of Syntheyes, ask to save its current scene first!
        if hlev.HasChanged():
            fuMessage("Syntheyes seems to have unsaved changes! Please switch to Syntheyes and save/discard them.")
            hlev.SaveIfChanged()
    else:
        if VERBOSE:
            print "Launching %s" % SyPy.syconfig.SynthEyesPath()
        rv = hlev.OpenSynthEyes(SYPORT, SYPIN)
        if not rv:
            raise RuntimeError("Could not launch Syntheyes.")
    if VERBOSE:
        print "...connected!"


def main():
    global hlev
    syShot = None

    trimin    = int(tool.GetAttrs()['TOOLIT_Clip_TrimIn'][1])
    trimout   = int(tool.GetAttrs()['TOOLIT_Clip_TrimOut'][1])
    initialframe = int(tool.GetAttrs()['TOOLIT_Clip_InitialFrame'][1])

    opts = tool.GetData("SyntheyesTrackThis") or {}
    footage = comp.MapPath(tool.Clip[comp.CurrentTime])

    # Syntheyes needs the initial frame of the sequence so it doesn't just start somewhere in the middle.
    # This is unfortunate because Fusion's loader doesn't care which frame of the sequence you specify.
    s_dir, s_base = os.path.split(footage)
    rexp = re.match(r"(?P<base>.+?)(?P<fnum>\d*)(?P<ext>\.[a-z]+)$", s_base, re.IGNORECASE)
    try:
        rdict = rexp.groupdict()
        if int(rdict['fnum']) != initialframe:
            padding = len(rdict['fnum'])
            s_base = rdict['base'] + str(initialframe).zfill(padding) + rdict['ext']
            footage = os.path.join(s_dir, s_base)
            if VERBOSE:
                print "First frame of sequence: %s" % s_base
    except ValueError, AttributeError:
        # rexp didn't match or no frame number found...
        pass

    if footage == "" or os.path.isfile(footage) == False:
        raise RuntimeError("Loader doesn't contain a valid clip.")

    # if an existing .sni project has been found, ask to open it instead of creating a new project
    if 'snifile' in opts:
        fullpath = comp.MapPath(opts['snifile'])
        if os.path.isfile(fullpath):
            msg = "There seems to be an existing Syntheyes project for this Loader (%s). Click OK to reopen it or Cancel to start anew." % os.path.basename(fullpath)
            dialog = {1: {1: 'msg', 2: 'Text', 'Name': 'Question', 'Default': msg, 'Lines': 4, 'Wrap': True, 'ReadOnly': True}}
            if composition.AskUser("Syntheyes - Track This", dialog):
                print "Syntheyes - Track This!\nreopening project: %s" % opts['snifile']
                connectToSyntheyes()
                hlev.OpenSNI(fullpath)
                return

    # show user dialog
    ret = False
    while not ret:
        ret = popupOptions(opts)
        if not ret:
            raise RuntimeError("'Syntheyes - Track This!' aborted.")
        tool.SetData("SyntheyesTrackThis", ret)
        if ret['savesni'] and ret['snifile']:
            fullpath = comp.MapPath(ret['snifile'])
            if os.path.isfile(fullpath):
                # sni file already exists
                msg = "The file %s already exists and will be overwritten. Press Cancel to choose a new one." % fullpath
                dialog = {1: {1: 'msg', 2: 'Text', 'Name': 'Question', 'Default': msg, 'Lines': 4, 'Wrap': True, 'ReadOnly': True}}
                if not composition.AskUser("Syntheyes - Track This", dialog):
                    opts = ret
                    ret = False

    # fire up Syntheyes and open a new shot
    # TODO: allow a custom path to executable
    print "Syntheyes - Track This!\nfootage to track: %s" % footage
    connectToSyntheyes()
    if VERBOSE:
        print "New Scene, adding shot %s..." % footage
    rv = hlev.NewSceneAndShot(footage, ret['aspect'])
    if not rv:
        raise RuntimeError("Could not load footage.")

    syShot = hlev.Active().shot
    syCam  = syShot.cam

    if ret.setdefault('workarea', 0):
        if VERBOSE:
            print "Adjust shot range: %d-%d" % (trimin, trimout)
        hlev.BeginShotChanges(syShot)
        syShot.start = trimin
        syShot.stop = trimout
        hlev.AcceptShotChanges(syShot, "Set Shot Range")

    if ret['filmback'] > 0:
        # film backs: Syntheyes default, Arri Alexa (RAW), RED One 4K
        fbwidth = (24.892, 23.760, 22.11)[int(ret['filmback'])]
        if VERBOSE:
            print "Setting back plate width to %d mm" % fbwidth
        hlev.Begin(syShot)
        syShot.Set("backPlateWidth", fbwidth)
        hlev.Accept(syShot, "Set Back Plate Width")

    hlev.InitMenu()

    # auto tracking?
    if ret['autotrack']:
        fuMessage("Starting AUTO track. Please confirm solve dialog in Syntheyes so this script can continue.")
        hlev.SetRoom("Summary")
        hlev.Main().ByName("AUTO").ClickAndWait()
        if VERBOSE:
            print "Finished AUTO track"

    # save scene?
    # TODO: test handling of non-existing and non-writable directories
    if ret['savesni'] and ret['snifile']:
        snifile = composition.MapPath(ret['snifile'])
        if os.path.dirname(snifile) == "":
            # if user only gave a file name without a path, use "Comp:"
            snifile = os.path.join(composition.MapPath("Comp:"), snifile)
        snidir = os.path.dirname(snifile)
        try:
            if not os.path.isdir(snidir):
                os.makedirs(snidir)
                if VERBOSE:
                    print "Created directory %s" % snidir
            print "Saving .sni: %s" % os.path.abspath(snifile)
            hlev.SetSNIFileName(os.path.abspath(snifile))
            hlev.ClickTopMenuAndWait("File", "Save")
            #hlev.SaveIfChanged()
        except OSError:
            fuMessage("Can't create %s. Syntheyes project has not been saved." % snidir)

    # start export script to send tracking results back to Fusion?
    #if ret.setdefault('autoupdate', 0):
    #    print "Updating Fusion composition"

    hlev.Close()
    print "completed\n"


#####

try:
    # perform initial checks, then launch main function
    try:
        if tool is None:
            tool = comp.ActiveTool
    except NameError:
        tool = comp.ActiveTool

    if (not tool) or (tool.ID != "Loader"):
        raise RuntimeError("You must select a Loader in the flow to run this script.")

    main()

except RuntimeError as e:
    composition.GetFrameList()[1].SwitchMainView('ConsoleView') 
    print e


# fin