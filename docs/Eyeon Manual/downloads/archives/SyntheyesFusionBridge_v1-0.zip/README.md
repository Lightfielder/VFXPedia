Syntheyes/Fusion Bridge
=======================

by Stefan Ihringer (http://www.comp-fu.com)  
release 1.0beta - 2014-01-26

These scripts facilitate your Fusion/Syntheyes workflow. The package consists of
three scripts. Except for the regular Fusion 6 exporter, the Pro version of
Syntheyes 2013.11 or later is required to run them. Unfortunately, older
versions or the Intro license don't support Python scripting. The minimum
version of Fusion is untested but it's probably 6.1 (which introduced Python
support).


Installation
------------

1. Put the scripts in the Syntheyes folder (fusion6.szl and send2fusion.py)
   into your SynthEyes user scripts folder. You can open this location via
   Syntheyes' "Script" menu. After restarting SynthEyes, you will find the
   "Fusion 6 Composition" option in the File > Export menu as well as "*Send To
   Fusion" in the Scripts menu.

2. Put the file in the Fusion folder (Syntheyes - Track This!.py) into Fusion's
   tool scripts folder (if you have only one path map, this would probably be
   C:\Users\Public\Documents\eyeon\Fusion\Scripts\Tool)

Optional: To install the tool script in the context menu of every Loader in
Fusion, place this snippet into your Fusion.menus file. It can be found in
C:\ProgramData\eyeon\Fusion\Profiles\Default\

    Loader = {
        { "Track This", [[@Scripts:Tool\Syntheyes - Track This!.py]] },
    },


Fusion to Syntheyes
-------------------

You can run the tool script "Syntheyes - Track This!" on Loaders. A dialog will
pop up where you can set up some options for SynthEyes but in general you can
just press OK to open Syntheyes with your footage already loaded.

The options in the dialog are:

* Image Aspect: Leave at 0 for autodetection. A value of 1.33333 for example
  will force Syntheyes to interpret the footage as 4:3.

* Film Back Width: You should set this to the camera's film back. If it's
  unknown leave it at the default. If you know the film back but it's not
  listed, drop me a line and I'll add it. You can always change the file back in
  Syntheyes.

* Auto-Track Footage: start autotracking immediately.

* Save .sni project and Syntheyes Project File Name: this will save the
  Syntheyes project using the given file name. The default location is in the
  current composition's folder and the name is based on the clip name.

If the Loader has been trimmed (Trim In > 0) there's an additional option at the
top of the dialog. You can choose whether you want to track the whole clip or
just the trimmed range that you have set up in Fusion. Sometimes, it's useful to
have some handles to achieve a better solve even though you won't use these
frames in comp.

The script will save its options in the Loader's metadata. If you run the script
a second time it may ask you whether you want to re-open the Syntheyes project
you've saved or start over with a new one.


Syntheyes to Fusion
-------------------

There are several ways to transfer your camera track and solve back to Fusion.
You can always use the Fusion 5 exporter that ships with Syntheyes, but this
package provides two better alternatives. They have advantages and
disadvantages. Pick the one that suits your workflow best.


### File > Export > Fusion 6 Composition

To export a new comp from scratch, use the *Fusion 6 Composition* exporter. It
is based on the old one by Russ Andersson and thus is very feature-rich but it
has been made even better. It supports stereo cameras, tracker meshes (as obj
files) and moving objects, normal and far point clouds as well as 3D planar
trackers.

It contains a couple of bug fixes and convenience features like locking the
Camera3D and saving the footage that the camera belongs to in the tool's
comments field.

These are the options of the Fusion 6 Composition exporter:

* Timeline setup: Define how the comp's timeline will be set up in Fusion.

  * Entire Shot starts @ 0 (or 1 if you have configured Syntheyes that way)
    will place your footage in Fusion the way it has been in Syntheyes.

  * Active Parts starts @ 0 (or 1 respectively). This will only result in a
    different timeline than the previous option if you have changed the start
    frame in Syntheyes. The timeline in Fusion will only contain the range you
    have defined in the preferences and it will start at frame zero.

  * Match image seq. numbers: This will set up your Fusion timeline to use the
    frame numbers of your image sequence.

* Relative screen distance: Defines how far back the camera's image plane is.

* Animate FL, not FOV: This will animate the focal length instead of the
  camera's field of view.

* Export 3D planar trackers: see below

* Include prefs/comments: This will save a short comment in the composition
  to help you identify the source project and footage used for the camera
  track.


### 3D Planar Trackers

3D planar trackers in Syntheyes are a new feature and most exporters don't
support them yet. For this reason, Syntheyes ships with a script called "Planar
Export Preparation". It will turn 3D planar trackers into moving objects (plane
meshes). The Fusion 6 exporter no longer needs this script, but it still has its
uses since it allows you to convert a moving planar tracker into a moving-camera
shot.

Whatever your intention is, you have these options when exporting:

* Export 3D planar trackers *ON*: If your shot has planar trackers, they will be
  exported as ImagePlane3D objects. If your shot had planar trackers, but you
  have run the export prep script, the exporter will detect this and use
  ImagePlane3D tools anyways (instead of regular Shape3D tools.)

* Export 3D planar trackers *OFF*: If your shot has planar trackers, they won't
  show up in your Fusion comp. You need to run the export prep script which
  turns them into plane meshes that will be exported as Shape3D tools.

The planar tracker option will create ImagePlane3D nodes instead of plane meshes
(Shape3D tools). These image planes will match the width but not the aspect of
the original planar tracker. However, they preserve the aspect of the connected
footage which is usually what you want when using planar tracking to put images
onto walls. You can replace the ImagePlane3D tools with Shape3D tools using
Fusion's context menu. Uncheck "Lock X/Y/Z" in the "Scale" section to lock the
Shape3D to the planar tracker's original aspect.


### Script > Send To Fusion

The script send2fusion.py takes a totally different approach. Instead of
creating a comp from scratch, it is able to spawn and update tools in a life
Fusion session on the same computer. This is very useful if you want to refine a
solve but don't want to redo your comp. When creating a comp for the first time,
the script uses the same layout and naming convention as the Fusion 6 exporter.
In order to be able to update a comp later, you mustn't rename the tools it has
created. You can, however, rearrange or reconnect them.

"Send To Fusion" doesn't provide any options (yet). You just launch it and if
Fusion isn't running yet, it will look for the most recent version you have
installed (currently supported are 6.3 and 6.4).

The script will spawn its tools in the current composition. If no comp is
opened, a blank one will be created. If an appropriate Loader exists in a comp
(for example if you have initially used the "Syntheyes - Track This" script) it
will be used as the base for the whole 3D setup. The script is smart enough to
detect the actual frame range used in the Loader. You can also slip the Loader
in time and the script will still be able to work its magic.

Differences to regular exporter:

* meshes, object-relative point clouds, lights and far points are currently not
  supported.

* if a new Loader needs to be created, it will mimick the frame range of your
  Syntheyes project (first frame 0 or 1 or matching actual image sequence
  numbers). If a loader already exists, it will be updated, taking into account
  any frame offset or trimming.

* only image sequences are currently supported (no quicktime/avi).


Troubleshooting
---------------

> Nothing happens when I launch "Send to Fusion"

The Python path in the Syntheyes preferences might be wrong. It defaults to
C:\Python27.




