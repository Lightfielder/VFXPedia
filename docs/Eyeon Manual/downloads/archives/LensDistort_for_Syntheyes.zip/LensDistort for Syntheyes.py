## LensDistort for Syntheyes
## by Stefan Ihringer, stefan@bildfehler.de
##
## Both Syntheyes and 3D Equalizer are using the same formula for their most basic
## radially symmetric lens distortion model: r' = r * (1 + k * r_squared)
## However, they differ in their assumption of what constitutes a radius of 1.0.
## This results in different coefficients k for the same formula.
## This tool script must be used on a LensDistort tool (available since Fusion 6.3)
## and allows you to enter a Syntheyes distortion coefficient (unfortunately, cubic
## distortion isn't supported by 3DE's lens model so it can't be converted).
##
## You need to set the LensDistort's film back to the one used by Syntheyes. Beware:
## the preset for Full Aperture plates differs in both applications! Moreoever, the
## LensDistort tools's mode button now works the opposite way. Use "Distort" to
## flatten your plate and "Undistort" to re-introduce distortion.

import math

try:
	
	try:
		if tool is None:
			tool = comp.ActiveTool
	except NameError:
		tool = comp.ActiveTool

	if (not tool) or (tool.ID != "LensDistort"):
		raise Exception("You must select a LensDistort tool in the flow to run this script.")
		
	w = tool.ApertureW[comp.TIME_UNDEFINED]
	h = tool.ApertureH[comp.TIME_UNDEFINED]

	# build user dialog
	dialog = {}
	dialog[1] = {1: 'info', 2: 'Text', 'Wrap': True, 'Lines': 4, 'Name': 'Info:', 'Default': "Make sure you set up the film back correctly. Beware: Fusion's preset for Full Aperture differs from Syntheyes!", 'ReadOnly': True }
	dialog[2] = {1: 'w', 2: 'Slider', 'Default': w, 'Name': 'Back Plate Width (in):'}
	dialog[3] = {1: 'h', 2: 'Slider', 'Default': h, 'Name': 'Back Plate Height (in):'}
	dialog[4] = {1: 'coeff', 2: 'Screw', 'Default': 0, 'Name': 'Distortion:'}

	# show dialog box
	ret = composition.AskUser("Syntheyes LensDistort:", dialog)

	if ret is not None:
		print(ret)
		w = ret['w']
		h = ret['h']
		tool.FilmGate = 'User'
		tool.ApertureW = w
		tool.ApertureH = h
		
		R_syn = h / 2
		R_3de = math.sqrt(w*w/4 + h*h/4)
		distortion = ret['coeff'] * math.pow((R_3de / R_syn), 2)
		
		tool.Model = 'DEClassicLDModel'
		tool.DEClassicLDModel.Distortion = distortion
		tool.Mode = 0.0


except Exception as e:
	print e
	
# fin