import xml.dom.minidom as dom
import sys

def read_file(filename):
        d = {}
        tree = dom.parse(filename)
        
        n = ("Slope"," 1.0 1.0 1.0")
        m = ("Offset"," 0.0 0.0 0.0")
        o = ("Power"," 1.0 1.0 1.0")
        pp = ("Saturation"," 1.0 ")
        
        for entry in tree.firstChild.childNodes:
                if entry.nodeName == "ColorCorrection":
                        cc_id = entry.getAttribute("id")
                        
                        for knots in entry.childNodes:
                                if knots.nodeName=="SOPNode":
                                        
                                        for sopknots in knots.childNodes:
                                                if sopknots.nodeName=="Slope":
                                                        slope = sopknots.firstChild.data
                                                        n=["Slope",slope]
                                                elif sopknots.nodeName=="Offset":
                                                        offset = sopknots.firstChild.data
                                                        m=["Offset",offset]
                                                elif sopknots.nodeName=="Power":
                                                        power = sopknots.firstChild.data
                                                        o=["Power",power]

                                elif knots.nodeName=="SatNode":
                                        for satknots in knots.childNodes:
                                                if satknots.nodeName=="Saturation":
                                                        #saturation = satknots.firstChild.data
                                                        pp = ("Saturation",satknots.firstChild.data)
                        d[cc_id] = (n,m,o,pp)
        return d
def create_dropdown_dict(ccc_nodes):
	n = 0
	d = {}
	for key in ccc_nodes:
		n=n+1
		d[n]=key
	return d

dialog = {1: {1: "dlgDir",   "Name": "Choose CCC (XML file)", 2: "FileBrowse"}
         }
ret = composition.AskUser("Choose a CDL CCC (Xml file)", dialog)

if ret != None:
    ccc_file = ret["dlgDir"]
else:
	print("user canceld")
	sys.exit()
	
CC_List = (read_file(ccc_file))

ccc_nodes = create_dropdown_dict(CC_List)

style = {1: "tool chain", 2: "CDL_CC macro"}

dialog2 = {}
dialog2 = {1:{1: "choose", 2: "Dropdown", "Options": ccc_nodes},
           2:{1: "add", 2: "Dropdown", "Options": style}}
ret2 = composition.AskUser("Choose CCC node", dialog2)


if ret2 != None:
	ccc_node_name = ccc_nodes[ret2["choose"]+1]
	print(ccc_node_name)

else:
	print("user canceld")
	sys.exit()


for a in CC_List[ccc_node_name]:
	if (a[0]=="Slope"):
		r_slope = float(a[1].split(" ")[1])
		g_slope = float(a[1].split(" ")[2])
		b_slope = float(a[1].split(" ")[3])
	elif (a[0]=="Offset"):
		r_Offset = float(a[1].split(" ")[1])
		g_Offset = float(a[1].split(" ")[2])
		b_Offset = float(a[1].split(" ")[3])
	elif (a[0]=="Power"):
		r_power = float(a[1].split(" ")[1])
		g_power = float(a[1].split(" ")[2])
		b_power = float(a[1].split(" ")[3])
	elif (a[0]=="Saturation"):
		master_saturation = float(a[1].split(" ")[1])

if (ret2["add"]==0):
	tool = composition.AddTool("ColorCorrector",True, -32768, -32768)
	tool.SetAttrs({"TOOLS_Name": "Slope", "TOOLB_NameSet": True})
	tool.MasterRedGain=r_slope
	tool.MasterGreenGain=g_slope
	tool.MasterBlueGain=b_slope

	tool = composition.AddTool("ColorCorrector",True, -32768, -32768)
	tool.SetAttrs({"TOOLS_Name": "Offset", "TOOLB_NameSet": True})
	tool.MasterRedBrightness=r_Offset
	tool.MasterGreenBrightness=g_Offset
	tool.MasterBlueBrightness=b_Offset

	tool2 = composition.AddTool("ColorCorrector",True, -32768, -32768)
	tool2.SetAttrs({"TOOLS_Name": "Power", "TOOLB_NameSet": True})
	tool2.MasterRedGamma=1/r_power
	tool2.MasterGreenGamma=1/g_power
	tool2.MasterBlueGamma=1/b_power

	tool6 = composition.AddTool("BrightnessContrast",True, -32768, -32768)
	tool6.SetAttrs({"TOOLS_Name": "ClampAfterSOP", "TOOLB_NameSet": True})
	tool6.ClipBlack = 1
	tool6.ClipWhite = 1

	tool3 = composition.AddTool("Custom",True, -32768, -32768)
	tool3.SetAttrs({"TOOLS_Name": "Saturation", "TOOLB_NameSet": True})
	tool3.Intermediate1 = "(r1*.2126)+(g1*.7152)+(b1*.0722)"
	tool3.RedExpression = "i1+(n1*(r1-i1))"
	tool3.GreenExpression = "i1+(n1*(g1-i1))"
	tool3.BlueExpression = "i1+(n1*(b1-i1))"
	tool3.NameforNumber1 = "Saturation"
	tool3.NumberIn1 = master_saturation
	
	tool5 = composition.AddTool("BrightnessContrast",True, -32768, -32768)
	tool5.SetAttrs({"TOOLS_Name": "ClampAfterSat", "TOOLB_NameSet": True})
	tool5.ClipBlack = 1
	tool5.ClipWhite = 1
	
elif(ret2["add"]==1):
	path = composition.MapPath("Macros:\\")
	s= path+"CDL_CC.setting"
	f = eyeon.readfile(s)
	composition.Paste(f)

	toollist = composition.GetToolList(True).values()
	for i in toollist:
		i.Input1=r_slope
		i.Input2=g_slope
		i.Input3=b_slope
		i.Input4=r_Offset
		i.Input5=g_Offset
		i.Input6=b_Offset
		i.Input7=r_power
		i.Input8=g_power
		i.Input9=b_slope
		i.Input11=master_saturation






